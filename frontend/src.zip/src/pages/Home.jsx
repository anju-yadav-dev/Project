// import { Link } from "react-router-dom";
// import "../App.css";

// function Home() {
//   return (
//     <>
//       <section className="hero-section">
//         <div className="container text-center hero-content">
//           <h1 className="hero-title">LOSTIFY</h1>

//           <p className="hero-subtitle">
//             Intelligent Lost and Found Portal
//           </p>

//           <p className="hero-description">
//             Lost something on campus? Report it, search found items,
//             and discover possible matches quickly.
//           </p>

         
          
//           <div className="hero-buttons">
//   <Link to="/report-lost" className="btn btn-danger btn-lg">
//     Report Lost Item
//   </Link>

//   <Link to="/report-found" className="btn btn-success btn-lg">
//     Report Found Item
//   </Link>

//   <Link to="/search" className="btn btn-primary btn-lg">
//     Search Items
//   </Link>
// </div>


//         </div>
//       </section>

//       <section className="features-section">
//         <div className="container">
//           <h2 className="text-center fw-bold mb-5">
//             How LOSTIFY Works
//           </h2>

//           <div className="row g-4">
//             <div className="col-md-4">
//               <div className="feature-card">
//                 <div className="feature-icon">📢</div>
//                 <h3>Report</h3>
//                 <p>
//                   Report your lost item or submit details of an item
//                   you have found.
//                 </p>
//               </div>
//             </div>

//             <div className="col-md-4">
//               <div className="feature-card">
//                 <div className="feature-icon">🔍</div>
//                 <h3>Match</h3>
//                 <p>
//                   LOSTIFY searches available reports and shows
//                   possible matching items.
//                 </p>
//               </div>
//             </div>

//             <div className="col-md-4">
//               <div className="feature-card">
//                 <div className="feature-icon">✅</div>
//                 <h3>Recover</h3>
//                 <p>
//                   Submit your claim and recover your item after
//                   verification.
//                 </p>
//               </div>
//             </div>
//           </div>
//         </div>
//       </section>

//       <footer className="footer text-center">
//         <p className="mb-0">
//           © 2026 LOSTIFY | Smart Campus Lost & Found Portal
//         </p>
//       </footer>
//     </>
//   );
// }

// export default Home;
import { Link } from "react-router-dom";
import "./Home.css";

function Home() {
  const categories = [
    { icon: "📱", name: "Electronics" },
    { icon: "👛", name: "Wallets" },
    { icon: "🪪", name: "ID Cards" },
    { icon: "🔑", name: "Keys" },
    { icon: "🎒", name: "Bags" },
    { icon: "📚", name: "Books" },
  ];

  const recentItems = [
    {
      icon: "📱",
      name: "iPhone 13",
      type: "Lost",
      location: "Library",
      date: "2 hours ago",
    },
    {
      icon: "👛",
      name: "Brown Wallet",
      type: "Found",
      location: "Cafeteria",
      date: "4 hours ago",
    },
    {
      icon: "🔑",
      name: "Car Keys",
      type: "Lost",
      location: "Parking Area",
      date: "6 hours ago",
    },
  ];

  return (
    <div className="home-page">

      {/* HERO SECTION */}
      <section className="hero">

        <div className="container">
          <div className="row align-items-center min-vh-75">

            <div className="col-lg-7">

              <span className="hero-tag">
                ✨ Smart Campus Lost & Found
              </span>

              <h1 className="hero-title">
                Lost Something?
                <br />
                <span>Let LOSTIFY Find It.</span>
              </h1>

              <p className="hero-text">
                A smart and centralized platform to report, search
                and recover lost belongings across your campus.
              </p>

              <div className="hero-buttons">

                <Link to="/report-lost" className="btn main-btn">
                  🔍 Report Lost Item
                </Link>

                <Link to="/report-found" className="btn second-btn">
                  📦 Report Found Item
                </Link>

              </div>

              <div className="hero-search">

                <span>🔎</span>

                <input
                  type="text"
                  placeholder="Search lost or found items..."
                />

                <Link to="/search">
                  Search
                </Link>

              </div>

            </div>


            {/* HERO RIGHT SIDE */}
            <div className="col-lg-5 d-none d-lg-block">

              <div className="hero-visual">

                <div className="visual-circle"></div>

                <div className="main-bag">
                  🎒
                </div>

                <div className="floating-item phone">
                  📱
                </div>

                <div className="floating-item wallet">
                  👛
                </div>

                <div className="floating-item keys">
                  🔑
                </div>

                <div className="floating-item idcard">
                  🪪
                </div>

                <div className="found-badge">
                  ✓ Possible Match Found
                </div>

              </div>

            </div>

          </div>
        </div>

      </section>


      {/* STATS */}

      <section className="stats-section">

        <div className="container">

          <div className="stats-box">

            <div>
              <h3>120+</h3>
              <p>Items Reported</p>
            </div>

            <div className="stats-border">
              <h3>75+</h3>
              <p>Items Recovered</p>
            </div>

            <div>
              <h3>60+</h3>
              <p>Successful Matches</p>
            </div>

          </div>

        </div>

      </section>


      {/* CATEGORIES */}

      <section className="category-section">

        <div className="container">

          <div className="section-heading">

            <span>EXPLORE ITEMS</span>

            <h2>Browse by Category</h2>

            <p>
              Find what you're looking for quickly and easily.
            </p>

          </div>

          <div className="row g-4">

            {categories.map((category, index) => (

              <div
                className="col-6 col-md-4 col-lg-2"
                key={index}
              >

                <Link
                  to="/search"
                  className="category-card"
                >

                  <div className="category-icon">
                    {category.icon}
                  </div>

                  <h6>{category.name}</h6>

                  <span>Explore →</span>

                </Link>

              </div>

            ))}

          </div>

        </div>

      </section>


      {/* HOW IT WORKS */}

      <section className="how-section">

        <div className="container">

          <div className="section-heading">

            <span>SIMPLE PROCESS</span>

            <h2>How LOSTIFY Works</h2>

            <p>
              Three simple steps to reconnect you with your belongings.
            </p>

          </div>


          <div className="row g-4">

            <div className="col-md-4">

              <div className="work-card">

                <div className="step-number">01</div>

                <div className="work-icon">
                  📝
                </div>

                <h4>Report Item</h4>

                <p>
                  Submit details and an image of the item
                  you lost or found.
                </p>

              </div>

            </div>


            <div className="col-md-4">

              <div className="work-card">

                <div className="step-number">02</div>

                <div className="work-icon">
                  🤖
                </div>

                <h4>Find Matches</h4>

                <p>
                  LOSTIFY displays possible matches using
                  item details and smart matching.
                </p>

              </div>

            </div>


            <div className="col-md-4">

              <div className="work-card">

                <div className="step-number">03</div>

                <div className="work-icon">
                  ✅
                </div>

                <h4>Claim & Recover</h4>

                <p>
                  Submit a claim, verify ownership and
                  recover your item safely.
                </p>

              </div>

            </div>

          </div>

        </div>

      </section>


      {/* RECENT REPORTS */}

      <section className="recent-section">

        <div className="container">

          <div className="recent-title">

            <div>
              <span>RECENT ACTIVITY</span>
              <h2>Recently Reported Items</h2>
            </div>

            <Link to="/search">
              View All →
            </Link>

          </div>


          <div className="row g-4">

            {recentItems.map((item, index) => (

              <div
                className="col-md-4"
                key={index}
              >

                <div className="recent-card">

                  <div className="recent-image">
                    {item.icon}
                  </div>

                  <div className="recent-info">

                    <span
                      className={
                        item.type === "Lost"
                          ? "lost-label"
                          : "found-label"
                      }
                    >
                      {item.type}
                    </span>

                    <h5>{item.name}</h5>

                    <p>
                      📍 {item.location}
                    </p>

                    <small>
                      🕒 {item.date}
                    </small>

                  </div>

                </div>

              </div>

            ))}

          </div>

        </div>

      </section>


      {/* CTA */}

      <section className="cta-section">

        <div className="container">

          <div className="cta-box">

            <div>

              <h2>
                Lost something on campus?
              </h2>

              <p>
                Report it now and let LOSTIFY help you find it.
              </p>

            </div>

            <Link to="/report-lost">
              Report Lost Item →
            </Link>

          </div>

        </div>

      </section>

    </div>
  );
}

export default Home;