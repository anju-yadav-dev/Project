// import { } from "react-router-dom";
// function Navbar() {
//   return (
//     // <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
//     <nav className="navbar navbar-expand-lg custom-navbar">
//       <div className="container">
        
//         <a className="navbar-brand fw-bold" href="/">
//           LOSTIFY
//         </a>

//         <button
//           className="navbar-toggler"
//           type="button"
//           data-bs-toggle="collapse"
//           data-bs-target="#navbarNav"
//         >
//           <span className="navbar-toggler-icon"></span>
//         </button>

//         <div className="collapse navbar-collapse" id="navbarNav">
//           <ul className="navbar-nav ms-auto">

//             <li className="nav-item">
//               <a className="nav-link" href="/">
//                 Home
//               </a>
//             </li>

//             <li className="nav-item">
//               <a className="nav-link" href="#">
//                 Report Lost
//               </a>
//             </li>

//             <li className="nav-item">
//               <a className="nav-link" href="#">
//                 Report Found
//               </a>
//             </li>

//             <li className="nav-item">
//               <a className="nav-link" href="#">
//                 Search
//               </a>
//             </li>

//             <li className="nav-item">
//               <a className="nav-link" href="#">
//                 Login
//               </a>
//             </li>

//           </ul>
//         </div>
//       </div>
//     </nav>
//   );
// }


// export default Navbar;
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg custom-navbar">
      <div className="container">

        <Link className="navbar-brand fw-bold" to="/">
          LOSTIFY
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">

            <li className="nav-item">
              <Link className="nav-link" to="/">
                Home
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/report-lost">
                Report Lost
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/report-found">
                Report Found
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/search">
                Search
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/login">
                Login
              </Link>
            </li>

          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;