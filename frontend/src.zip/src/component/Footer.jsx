import { Link } from "react-router-dom";
import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">

      <div className="container">

        <div className="row g-5">

          <div className="col-lg-4">

            <h2>LOSTIFY</h2>

            <p>
              An intelligent Lost and Found portal designed
              to make campus item recovery faster, smarter
              and more organized.
            </p>

            <div className="footer-tag">
              Find What Matters.
            </div>

          </div>


          <div className="col-6 col-lg-2">

            <h5>Quick Links</h5>

            <Link to="/">Home</Link>
            <Link to="/search">Browse Items</Link>
            <Link to="/report-lost">Report Lost</Link>
            <Link to="/report-found">Report Found</Link>

          </div>


          <div className="col-6 col-lg-2">

            <h5>Account</h5>

            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
            <Link to="/profile">Profile</Link>
            <Link to="/matches">Matches</Link>

          </div>


          <div className="col-lg-4">

            <h5>Lost Something?</h5>

            <p>
              Report your item and check for possible matches.
            </p>

            <Link
              to="/report-lost"
              className="footer-button"
            >
              Report an Item →
            </Link>

          </div>

        </div>


        <div className="footer-bottom">

          <span>
            © 2026 LOSTIFY. All Rights Reserved.
          </span>

          <span>
            Intelligent Lost and Found Portal
          </span>

        </div>

      </div>

    </footer>
  );
}

export default Footer;